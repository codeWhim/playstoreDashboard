<?php

session_start();

require_once "vendor/autoload.php";
require_once "config.php";
require_once "pdo_connection.php";
require_once "functions.php";
$config = getConfig();

?>
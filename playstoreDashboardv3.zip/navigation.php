
<nav class="navbar navbar-inverse navbar-fixed-top">
      <div class="container-fluid">
        <div class="navbar-header">
          <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
          <a class="navbar-brand" href="./" target="_blank">PlayStore Dashboard</a>
		
		
        </div>
		
		
		
        <div id="navbar" class="navbar-collapse collapse">
          <ul class="nav navbar-nav navbar-right">

            <li><a href="editAPKlistings.php">Edit APK Listings</a></li>
            <li><a href="editAPKs.php">Edit APKs</a></li>
            <li><a href="editImages.php">Edit Images</a></li>
            <li><a href="editListings.php">Edit Listings</a></li>
            <li><a href="editDetails.php">Edit Details</a></li>

		
		
          </ul>
		  <!--
		  
		  
		  TODO: Search bar for Future
          
		  
		  <form class="navbar-form navbar-right">
            <input type="text" class="form-control" placeholder="Search...">
          </form>-->
        </div>
      </div>
</nav>
<br /><br /><br />
<div class="container" role="main">
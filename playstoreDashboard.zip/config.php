<?php

$database_host = "localhost";
$database_name = "playstore";
$database_user = "root";
$database_password = "";

?>